

<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-top: 8rem">
      
            <div class="col">
                <div class="card listar">
                    <div class="card-body">
                        <h3 style="text-align: center;"> Tus citas Agendadas</h3>
                        <div class="table-responsive">
                            <table class="table" id="order-listing">
                                <thead>
                                    <tr>
                                        <th scope="col">CC</th>
                                        <th scope="col">Nombre Dueño</th>
                                        <th scope="col">Apellido Dueño</th>
                                        <th scope="col">Nombre Mascota</th>
                                        <th scope="col">Fecha Cita</th>
                                        <th scope="col">Hora</th>
                                        <th scope="col">opciones</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $diasFaltantes = $fechaActual->diffInDays($d->fecha_cita);
                                            $horasFaltantes = $d->fecha_cita->diffInRealHours($d->hora);
                                        ?>
                                        <tr>
                                            <td><?php echo e($d->cc); ?></td>
                                            <td><?php echo e($d->nombre); ?></td>
                                            <td><?php echo e($d->apellido); ?></td>
                                            <td><?php echo e($d->nombreMas); ?></td>
                                            <td><?php echo e($d->fecha_cita->format('Y-m-d')); ?></td>
                                            <td><?php echo e($d->fecha_cita->format('H:i')); ?></td>
                                            <?php if($horasFaltantes > 2 || $diasFaltantes >= 0): ?>
                                                <td><button type="button"
                                                        class="btn btn-warning btn-sm "data-bs-toggle="modal"
                                                        data-bs-target="#update<?php echo e($d->id); ?>">Modificar cita</button>
                                                </td>
                                            <?php else: ?>
                                                <td>No es el dia</td>
                                            <?php endif; ?>
                                        </tr>
                                        <!-- Modal update-->
                                        <div class="modal fade" id="update<?php echo e($d->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Actualizar cita
                                                            del cliente <?php echo e($d->nombre . ' ' . $d->apellido); ?></h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="<?php echo e(route('registrar.update', $d->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <div class="modal-body">
                                                            <div class="row ">
                                                                <div class="col">
                                                                    <label class="col-form-label">fecha Cita</label>
                                                                    <input type="datetime-local"
                                                                        class="form-control form-control-sm"
                                                                        name="fecha_cita" value="<?php echo e($d->fecha_cita); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Cerrar</button>
                                                            <button type="submit" class="btn btn-primary">
                                                                Guardar</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home/inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examen\resources\views/home/list.blade.php ENDPATH**/ ?>